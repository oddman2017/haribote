/* copyright(C) 2002 H.Kawai (under KL-01). */

/* #include <stddef.h> */

#if (!defined(STDDEF_H)) & 1

#define STDDEF_H	1

#if (defined(__cplusplus))
	extern "C" {
#endif

#include "go_lib.h"

/* size_t --> go_lib.h */

#if (defined(__cplusplus))
	}
#endif

#endif
