/* copyright(C) 2002 H.Kawai (under KL-01). */

#include <stdio.h>

/* 面倒なので一つのファイルで */
/* 初期化は、適当なルーチンがやる */

GO_FILE GO_stdin, GO_stdout, GO_stderr;
